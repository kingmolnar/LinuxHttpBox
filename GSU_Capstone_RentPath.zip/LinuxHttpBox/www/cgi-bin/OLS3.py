#!/usr/bin/python3
# Import modules for CGI handling 
import cgi, cgitb 
# Create instance of FieldStorage 
form = cgi.FieldStorage() 
cgitb.enable()
import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd
import datetime as dt
import seaborn as sns
sns.set(color_codes=True)
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import norm
import pylab
import datetime as dt
import statsmodels.formula.api as sm

#random package 
def randint(a, b):
    "Return random integer in range [a, b], including both end points."
    return a + randbelow(b - a + 1)

def randbelow(n):
    "Return a random int in the range [0,n).  Raises ValueError if n<=0."
    if n <= 0:
       raise ValueError
    k = n.bit_length()
    numbytes = (k + 7) // 8
    while True:
        r = int.from_bytes(random_bytes(numbytes), 'big')
        r >>= numbytes * 8 - k
        if r < n:
            return r

def random_bytes(n):
    "Return n random bytes"
    with open('/dev/urandom', 'rb') as file:
        return file.read(n)


def list_of_column(df):
    return df.columns.values
	
	
#random package 
def randint(a, b):
    "Return random integer in range [a, b], including both end points."
    return a + randbelow(b - a + 1)

def randbelow(n):
    "Return a random int in the range [0,n).  Raises ValueError if n<=0."
    if n <= 0:
       raise ValueError
    k = n.bit_length()
    numbytes = (k + 7) // 8
    while True:
        r = int.from_bytes(random_bytes(numbytes), 'big')
        r >>= numbytes * 8 - k
        if r < n:
            return r

def random_bytes(n):
    "Return n random bytes"
    with open('/dev/urandom', 'rb') as file:
        return file.read(n)
		
def draw_linear_regression(df,x,y):
    df = df.dropna() 
    # Fit the model
    a = df[x]
    b = df[y]
    slope, intercept, r_value, p_value, slope_std_error = stats.linregress(a, b)
    
    predict_y = intercept + slope * a
    
    # Plotting
    pylab.xlabel(x)
    pylab.ylabel(y)
    pylab.plot(a, b, 'o')
    pylab.plot(a, predict_y, '-r')
	
    pylab.savefig('/vagrant/www/html/figs/linearRegression3.png',bbox_inches='tight')
	
	#pic_save = '/vagrant/www/html/figs/linearRegression' + 'x' + '.png'

	#pylab.savefig(pic_save)

print("Content-Type: text/html\r\n\r\n")
print('<html>')
print('<title>Linear Regression</title>')
print('<body>')
print('<h2>Check OLS Regression Results Link</h2>')

#import dataset
df = pd.read_csv('/vagrant/www/html/datasets/current_df.csv')

#get y variable 
columns = len(list_of_column(df)[1:])
list_of_column_name = list_of_column(df)[1:]
lst = []
for i in range(columns):
	k = str(i)
	if form.getvalue(k):
		lst.append(list_of_column_name[i])
y = lst[0]

#get x variable
file = open("/vagrant/www/html/figs/x_variable.txt", 'r') 
x = file.read() 

#random number r		
r = randint(1000,9999)
r = str(r)
#pic_save = "/vagrant/www/html/figs/linearRegression" + r + ".png"
#draw linear regression diagram
draw_linear_regression(df,x,y)
print("<img src='../figs/linearRegression3.png'>")

#r = draw_linear_regression(df,x,y)
#pic_open = "<img src='../figs/linearRegression" + r + ".png'>"
#print(pic_open)

print('</body>')
print('</html>')




#generate and display ols summary
string = y + "~" + x
result=sm.ols(formula=string, data=df,missing='drop').fit()
result = result.summary().as_html()
print(result)

#print out terminology explanation 
print ("<h2><a id='title'></a>Terminology</h2>")
print ("<p><code>DF Residuals:</code>The degrees of freedom of the residuals is the number of observations minus the degrees of freedom of the model, minus one (for the offset).</p>")
print ("<p><code>DF Model:</code>The degrees of freedom of the model are the number of predictor, or explanatory variables</p>")
print ("<p><code>R-squared:</code>R-squared of the regression is the fraction of the variation in your dependent variable that is accounted for (or predicted by) your independent variables. </p>")
print ("<p><code>Adj. R-squared:</code>Adj R2 shows the same as R2 but adjusted by the # of cases and # of variables. When the # of variables is small and the # of cases is very large then Adj R2 is closer to R2. This provides a more honest association between X and Y. </p>")
print ("<p><code>F-statistic:</code>The F value is the ratio of the mean regression sum of squares divided by the mean error sum of squares.  Its value will range from zero to an arbitrarily large number.</p>")
print ("<p><code>Prob (F-statistic):</code>The value of Prob(F) is the probability that the null hypothesis for the full model is true.</p>")
print ("<p><code>Log-Likelihood:</code>The log-likelihood is the expression that Minitab maximizes to determine optimal values of the estimated coefficients.</p>")
print ("<p><code>Std err:</code>The degrees of freedom of the model are the number of predictor, or explanatory variables</p>")
print ("<p><code>t:</code>The t statistic is the coefficient divided by its standard error.</p>")
print ("<p><code>p>|t|:</code>Two-tail p-values test the hypothesis that each coefficient is different from 0. To reject this, the p-value has to be lower than 0.05 (you could choose also an alpha of 0.10)</p>")
print ("<p><code>p:</code>The P value tells you how confident you can be that each individual variable has some correlation with the dependent variable, which is the important thing.</p>")
print ("<p><code>95.0% Confi.Int.:</code>95% probability of being correct that the variable is having some effect, assuming your model is specified correctly.</p>")




