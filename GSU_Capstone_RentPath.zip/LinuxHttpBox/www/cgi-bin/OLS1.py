#!/usr/bin/python3
# Import modules for CGI handling 
import cgi, cgitb 
import numpy as np
import pandas as pd
import datetime as dt
# Create instance of FieldStorage 
form = cgi.FieldStorage() 
cgitb.enable()
#import dataset
df = pd.read_csv('/vagrant/www/html/datasets/current_df.csv')



def list_of_column(df):
    return df.columns.values
	


print("Content-type:text/html\r\n\r\n")
print('<html>')
print('<head>')
print('<title>Linear Regression</title>')

print('</head>')
print('<body>')

#let user select x variable
print('<h2>Please Select your X</h2>')
k = "0"
print ("<form action='/cgi-bin/OLS2.py' method='POST' target='_blank'>")
for i in list_of_column(df)[1:]:
	output = "<input type='checkbox' name=" + k + " value='on' /> %s"
	print(output % (i))
	print("<br />")
	k = str(int(k)+1)
print("<br />")
print ("<input type='submit' value='Select Columns' />")

print ("</form>")
print('</body>')
print('</html>')


