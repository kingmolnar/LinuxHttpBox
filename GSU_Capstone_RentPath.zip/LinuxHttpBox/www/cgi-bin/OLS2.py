#!/usr/bin/python3
# Import modules for CGI handling 
import cgi, cgitb 
import numpy as np
import pandas as pd
import datetime as dt
# Create instance of FieldStorage 
form = cgi.FieldStorage() 
cgitb.enable()

#import dataset
df = pd.read_csv('/vagrant/www/html/datasets/current_df.csv')

def list_of_column(df):
    return df.columns.values

print("Content-type:text/html\r\n\r\n")
print('<html>')
print('<head>')
print('<title>Linear Regression</title>')
print('</head>')
print('<body>')

#save x value to "x_variable.txt"
columns = len(list_of_column(df)[1:])
list_of_column_name = list_of_column(df)[1:]
lst = []
for i in range(columns):
	k = str(i)
	if form.getvalue(k):
		lst.append(list_of_column_name[i])
x = lst[0]
text_file = open("/vagrant/www/html/figs/x_variable.txt", "w")
text_file.write(x)
text_file.close()

#let user select y variable
print('<h2>Please Select your Y</h2>')
k = "0"
print ("<form action='/cgi-bin/OLS3.py' method='POST' target='_blank'>")
for i in list_of_column(df)[1:]:
	output = "<input type='checkbox' name=" + k + " value='on' /> %s"
	print(output % (i))
	print("<br />")
	k = str(int(k)+1)
print("<br />")
print("<input type='submit' value='Select Columns' />")
print("</form>")
print('</body>')
print('</html>')








