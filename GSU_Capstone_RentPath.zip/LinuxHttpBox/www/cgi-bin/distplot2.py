#!/usr/bin/python3
import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd
import datetime as dt
import seaborn as sns
sns.set(color_codes=True)
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import norm
import pylab
import datetime as dt
import statsmodels.formula.api as sm
# Import modules for CGI handling 
import cgi, cgitb 
# Create instance of FieldStorage 
form = cgi.FieldStorage() 
cgitb.enable()


#random package 
def randint(a, b):
    "Return random integer in range [a, b], including both end points."
    return a + randbelow(b - a + 1)

def randbelow(n):
    "Return a random int in the range [0,n).  Raises ValueError if n<=0."
    if n <= 0:
       raise ValueError
    k = n.bit_length()
    numbytes = (k + 7) // 8
    while True:
        r = int.from_bytes(random_bytes(numbytes), 'big')
        r >>= numbytes * 8 - k
        if r < n:
            return r

def random_bytes(n):
    "Return n random bytes"
    with open('/dev/urandom', 'rb') as file:
        return file.read(n)

#generates random number r	
r = randint(1000,9999)

def list_of_column(df):
    return df.columns.values

def remove_nan_from_array(df,column):
    s = np.nan_to_num(df[column])
    
    for i in s:
        if np.absolute(i) >= np.absolute(s.mean() + (3*s.std())):
            i = 0.0
            
    s = df[column][s != 0.0] 

    return  s   
	
def distplot(df,column):
 
    
    array_without_none = remove_nan_from_array(df,column)
	

    return sns.distplot(array_without_none)  

#import dataset	
df = pd.read_csv('/vagrant/www/html/datasets/current_df.csv')	

#get selected column
columns = len(list_of_column(df))
list_of_column_name = list_of_column(df)
print ("Content-type:text/html\r\n\r\n")
print ("<html>")
print ("<head>")
print ("<title>Distribution Plot</title>")
print ("</head>")
print ("<body>")
lst = []
for i in range(columns):
	k = str(i-1)
	if form.getvalue(k):
		lst.append(list_of_column_name[i])
			
column = lst[0]

#display distribution plot
sns.set_color_codes()
try:
	seaborn_plot = distplot(df,column)
	seaborn_plot = seaborn_plot.get_figure()
	r = str(r)
	pic_save = "/vagrant/www/html/figs/distplot" + r + ".png"
	seaborn_plot.savefig(pic_save)
	pic_open = "'<img src='../figs/distplot" + r + ".png' height='300' width='300'>"
	print(pic_open)
	
	print(("<p>%s </p>")% (column))
	
except TypeError:
	print('<h3>Please select a column with a numeric value!</h3>')
	


print ("</body>")
print ("</html>")




