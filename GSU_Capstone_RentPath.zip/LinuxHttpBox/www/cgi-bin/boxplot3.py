#!/usr/bin/python3
# Import modules for CGI handling 
import cgi, cgitb 
# Create instance of FieldStorage 
form = cgi.FieldStorage() 
cgitb.enable()

import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd
import datetime as dt
import seaborn as sns
sns.set(color_codes=True)
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import norm
import pylab
import datetime as dt
import statsmodels.formula.api as sm



#random package 
def randint(a, b):
    "Return random integer in range [a, b], including both end points."
    return a + randbelow(b - a + 1)

def randbelow(n):
    "Return a random int in the range [0,n).  Raises ValueError if n<=0."
    if n <= 0:
       raise ValueError
    k = n.bit_length()
    numbytes = (k + 7) // 8
    while True:
        r = int.from_bytes(random_bytes(numbytes), 'big')
        r >>= numbytes * 8 - k
        if r < n:
            return r

def random_bytes(n):
    "Return n random bytes"
    with open('/dev/urandom', 'rb') as file:
        return file.read(n)



def list_of_column(df):
    return df.columns.values

#def remove_nan_abnormal_to_new_array(df,column):
#	try:
#		for i in range(len(df[column])):
#			k = df[column].mean() + (3*df[column].std())
#			if np.absolute(df[column][i]) >= np.absolute(k):
#				df[column][i] = None
#				
#       df[column] = df[column].dropna()
#      
#     return df[column]
#    
#   except KeyError:
#	    return df[column]
	 

    

	
#import dataset
df = pd.read_csv('/vagrant/www/html/datasets/current_df.csv')	


#get y variable 
columns = len(list_of_column(df)[1:])
list_of_column_name = list_of_column(df)[1:]
lst = []
for i in range(columns):
	k = str(i)
	if form.getvalue(k):
		lst.append(list_of_column_name[i])
y = lst[0]

#get x variable
file = open("/vagrant/www/html/figs/x_variable_boxplot.txt", 'r') 
x = file.read() 

print ("Content-type:text/html\r\n\r\n")
print ("<html>")
print ("<head>")
print ("<title>BoxPlot</title>")
print ("</head>")
print ("<body>")

		
#draw boxplot

#df[x] = remove_nan_abnormal_to_new_array(df,x)

ax = sns.boxplot(x=x,y =y,data=df)

#random number r		
r = randint(1000,9999)
r = str(r)
	
pic_name = "/vagrant/www/html/figs/boxplot_output" + r + ".png"
pic_name2 = "<img src='../figs/boxplot_output" + r + ".png'"

ax.get_figure().savefig(pic_name)
	
print(pic_name2)
	
print ("</body>")
print ("</html>")






