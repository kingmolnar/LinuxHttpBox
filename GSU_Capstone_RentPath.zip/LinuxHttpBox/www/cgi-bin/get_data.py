#!/usr/bin/python3

#Don't forget to install tkinter in your vagrant '$ sudo yum install python34-tkinter'

# Import modules for CGI handling 
import cgi, cgitb 
# Create instance of FieldStorage 

form = cgi.FieldStorage() 
cgitb.enable()

print ("Content-type:text/html\r\n\r\n")
print ("<html>")
print ("<head>")
print ("<title>Get Dataset</title>")
print ("</head>")
print ("<body>")
print('<h2>Please upload your dataset</h2>')
print ("<form enctype='multipart/form-data' action='select_columns.py' method='post'>")
print ("<p>File: <input type='file' name='filename' /></p>")
print ("<p><input type='submit' value='Upload' /></p>")
print ("</form>")
print ("</body>")
print ("</html>")






