#!/usr/bin/python3
import cgi, os
import cgitb; cgitb.enable()
import numpy as np
import pandas as pd
import datetime as dt
form = cgi.FieldStorage()
cgitb.enable()


# Get filename here.
fileitem = form['filename']

# Test if the file was uploaded
if fileitem.filename:
   # strip leading path from file name to avoid 
   # directory traversal attacks
   fn = os.path.basename(fileitem.filename.replace("\\", "/" ))
   open('/vagrant/data/' + fn, 'wb').write(fileitem.file.read())

   message = 'The file "' + fn + '" was uploaded successfully'
   
else:	
   message = 'No file was uploaded'
      

def eliminate_abnormal_value(df):
    for i in df:
        if df[i].dtypes in ["int64", "float64", "int", "float"]:
            for j in range(len(df[i])):
                if np.absolute(df[i][j]) >= np.absolute(df[i].mean() + (3*df[i].std())):
                    df[i][j] = None
    
    return df
    
def remove_nan_from_array(df,column):
    s = np.nan_to_num(df[column])
    
    for i in s:
        if np.absolute(i) >= np.absolute(s.mean() + (3*s.std())):
            i = 0.0
            
    s = df[column][s != 0.0] 

    return  s    
 
#show blank/omitted data(NA or NaN)
def isnan(df, column):
    return df[np.isnan(df[column])]
	
	
#return list of column names
def list_of_column(df):
    return df.columns.values
    
#missing value rate in each column        
def missing_value_rate(df,column):
    missed = df[column].isnull().values.ravel().sum()
    amount = len(df[column])
    
    rate = missed/amount
    
    return rate 

#amount of distinct value
def distinct(df,column):
    a = np.unique(df[column])
    return len(a)

#amount of value
def count(df,column):
    a = len(df[column])
    return a 
 
#transform string to datetime data type
def datetime(df):
    descdf = df.describe()
    set_of_datecolumns = set(df.columns).difference(set(descdf.columns))
    for i in set_of_datecolumns:
        try:
            df[i] = pd.to_datetime(df[i])
        except ValueError:
            try:
                for j in range(len(df[i])):
                    df[i][j] = dt.datetime.strptime(df[i][j], "%Y/%m/%d")
                df[i] = pd.to_datetime(df[i])
            except ValueError:
                try:
                    for j in range(len(df[i])):
                        df[i][j] = dt.datetime.strptime(df[i][j], "%Y/%m/%d %H/%M/%S")
                    df[i] = pd.to_datetime(df[i])
                except ValueError:
                    pass 
    
    return df

#output basic information table
def basic_information(df):
    df1 = datetime(df)
    df1 = eliminate_abnormal_value(df1)
	
    columns = ['Data_Type', 'Total','Distinct_Value', 'Missing_Value_Rate','Min','Max', 'Mean','Median','Average','Standard_Deviation']
    index = df1.columns.values
    
    table = pd.DataFrame(index=index, columns=columns)
    table.fillna(" ")
    
    for var in index:
        table['Total'][var] = count(df1,var)
        table['Distinct_Value'][var] = distinct(df1,var)
        table['Missing_Value_Rate'][var] = missing_value_rate(df1,var)
        table['Total'][var] = count(df1,var)
        table['Data_Type'][var] = df1[var].dtypes

        
        try:
            table['Standard_Deviation'][var] = np.std(df1[var])
        except TypeError:
            table['Standard_Deviation'][var] = " "
            
        
        
        
    table['Mean'] = df1.mean()
    table['Max'] = df1.max()
    table['Min'] = df1.min()
    table['Median'] = df1.median()
    table['Average'] = df1.mean()

    
        
    return table
        
#If query is more than 100,000 lines, random sampling 10% of them automatically
def random_sampling_100000(df):
    if len(df) >= 100000:
        df = df.sample(frac=0.1, replace=True)
    
    return df    

#import dataset into current_df		
dataset = '/vagrant/data/' + fn
current_df = pd.read_csv(dataset)

#if more than 100000 rows, random sample the dataset	
current_df = random_sampling_100000(current_df)

#save current_df as file 'current_df.csv' in local
current_df.to_csv('../html/datasets/current_df.csv')


print("Content-Type: text/html\n")
print("<html>")
print("<body>")
print ("<title>Select Columns You Need</title>")
print(("<p>%s </p>")% (message))

#display first 10 rows of the dataset
header = current_df.head(10)
header.to_html('../html/outputs/header.html')
print("<a href='../outputs/header.html'>Click to view first 10 rows of all columns</a>")
print("<br />")
print("<br />")
print("<body>")
print("<html>")


#display columns for uses to select
print("<b>List of all columns - Select the ones you want to operate on:</font></b>")
k = "1"
print ("<form action='/cgi-bin/menu.py' method='POST' target='_blank'>")
print("<br>")
for i in list_of_column(current_df):
	output = "<input type='checkbox' name=" + k + " value='on' /> %s"
	print(output % (i,))
	print("<br />")
	k = str(int(k)+1)
print("<br />")	
print ("<input type='submit' value='Go' />")
print ("</form>")











