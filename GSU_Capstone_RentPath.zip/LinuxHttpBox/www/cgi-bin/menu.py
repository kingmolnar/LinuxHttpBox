#!/usr/bin/python3
# Import modules for CGI handling 
import cgi, cgitb 
import numpy as np
import pandas as pd
import datetime as dt
# Create instance of FieldStorage 
form = cgi.FieldStorage() 
cgitb.enable()


#return list of column names
def list_of_column(df):
    return df.columns.values

#remove all abnormal values from datasets	
def eliminate_abnormal_value(df):
    for i in df:
        if df[i].dtypes in ["int64", "float64", "int", "float"]:
            for j in range(len(df[i])):
                if np.absolute(df[i][j]) >= np.absolute(df[i].mean() + (3*df[i].std())):
                    df[i][j] = None
    
    return df
    
	
#remove all none value from a certain column
def remove_nan_from_array(df,column):
    s = np.nan_to_num(df[column])
    
    for i in s:
        if np.absolute(i) >= np.absolute(s.mean() + (3*s.std())):
            i = 0.0
            
    s = df[column][s != 0.0] 

    return  s    

 
#show blank/omitted data(NA or NaN)
def isnan(df, column):
    return df[np.isnan(df[column])]
    
#missing value rate in each column        
def missing_value_rate(df,column):
    missed = df[column].isnull().values.ravel().sum()
    amount = len(df[column])
    
    rate = missed/amount
    
    return rate 

#amount of distinct value
def distinct(df,column):
    if df[column].dtypes in ['float64', 'int64']:
        df[column] = df[column].tolist()
    elif df[column].dtypes in [object]:
        df[column] = df[column].astype(np.str)
        
    a = np.unique(df[column])
    return len(a)

#amount of value
def count(df,column):
    a = len(df[column])
    return a 
 
 
#transform string to datetime data type
def datetime(df):
    descdf = df.describe()
    set_of_datecolumns = set(df.columns).difference(set(descdf.columns))
    for i in set_of_datecolumns:
        try:
            df[i] = pd.to_datetime(df[i])
        except ValueError:
            try:
                for j in range(len(df[i])):
                    df[i][j] = dt.datetime.strptime(df[i][j], "%Y/%m/%d")
                df[i] = pd.to_datetime(df[i])
            except ValueError:
                try:
                    for j in range(len(df[i])):
                        df[i][j] = dt.datetime.strptime(df[i][j], "%Y/%m/%d %H/%M/%S")
                    df[i] = pd.to_datetime(df[i])
                except ValueError:
                    pass 
    
    return df

#output basic information table
def basic_information(df):
    df1 = datetime(df)
    df1 = eliminate_abnormal_value(df1)
	
    columns = ['Data_Type', 'Total','Distinct_Value', 'Missing_Value_Rate','Min','Max', 'Mean','Median','Average','Standard_Deviation']
    index = df1.columns.values
    
    table = pd.DataFrame(index=index, columns=columns)
    table.fillna(" ")
    
    for var in index:
        table['Total'][var] = count(df1,var)
        table['Distinct_Value'][var] = distinct(df1,var)
        table['Missing_Value_Rate'][var] = missing_value_rate(df1,var)
        table['Total'][var] = count(df1,var)
        table['Data_Type'][var] = df1[var].dtypes

        
        try:
            table['Standard_Deviation'][var] = np.std(df1[var])
        except TypeError:
            table['Standard_Deviation'][var] = " "
            
        
        
        
    table['Mean'] = df1.mean()
    table['Max'] = df1.max()
    table['Min'] = df1.min()
    table['Median'] = df1.median()
    table['Average'] = df1.mean()

    
        
    return table

#import dataset into df	
dataset = '/vagrant/www/html/datasets/current_df.csv'
df = pd.read_csv(dataset)

#get selected columns and generate a new 'current_df.csv'
columns = len(list_of_column(df))
list_of_column_name = list_of_column(df)
print ("Content-Type: text/html\n")
print ("<html>")
print ("<body>")
lst = []
for i in range(columns):
	k = str(i)
	k_flag = k + "_flag"
	if form.getvalue(k):
		lst.append(list_of_column_name[i])
		
current_df = df[lst]
current_df.to_csv('/vagrant/www/html/datasets/current_df.csv')
print ("</body>")
print ("</html>")

#generate basic information table and save it into 'basic_information.html'
basic_information = basic_information(current_df)
basic_information.to_html('../html/outputs/basic_information.html')

#display first 100 rows 
header = current_df.head(100)
header.to_html('../html/outputs/header2.html')

print("<html>")
print("<body>")
desc = "Please check the link below"
print(("<p>%s </p>")% (desc))
print("<a href='../outputs/header2.html'>First 100 rows</a>")
print("<br />")
print("<br />")
print("<br />")
print("<br />")
print("<a href='../outputs/basic_information.html'>Basic Information</a>")
print("<a href='../Basic_Info.html'>Basic Information Explanation</a>")
print("<br />")
print("<br />")
print("<br />")
print("<br />")
print("<body>")
print("<html>")
print("<a href='http://localhost:8080/cgi-bin/distplot1.py'>Distribution Plot</a>")
print("<a href='../Histogram.html'>Distribution and Histogram</a>")
print("<br />")
print("<br />")
print("<br />")
print("<br />")
print("<a href='http://localhost:8080/cgi-bin/OLS1.py'>Linear Regression</a>")
print("<br />")
print("<br />")
print("<br />")
print("<br />")
print("<a href='http://localhost:8080/cgi-bin/boxplot1.py'>Box Plot</a>")
print("<a href='../Univariate2.html'>Categorical Variable and Continuous Variables</a>")





